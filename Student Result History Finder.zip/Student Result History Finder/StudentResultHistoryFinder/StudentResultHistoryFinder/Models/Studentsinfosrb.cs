﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace StudentResultHistoryFinder.Models
{
    public class Studentsinfosrb
    {
        public int EnrollCourseID;
        public int StudentId;
        public int CourseID;
    }
}