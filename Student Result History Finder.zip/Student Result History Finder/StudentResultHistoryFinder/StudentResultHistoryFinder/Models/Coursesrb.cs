﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace StudentResultHistoryFinder.Models
{
    public class Coursesrb
    {
        public int courseid;
        public string coursecode;
    }
}