﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace StudentResultHistoryFinder.Models
{
    public class StudentMarks
    {
        public string StudentId;
        public string CT1;
        public string CT2;
        public string CT3;
        public string CT4;
        public string Attendance;
    }
}